package com.example.recovercovid19;

import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class login extends AppCompatActivity implements View.OnClickListener {
    private EditText email;
    private EditText password;
    private Button loginbutton;
    private FirebaseAuth firebaseAuth;
    private ProgressDialog progressDialog;
    TextView signup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        progressDialog=new ProgressDialog(this);
        firebaseAuth=firebaseAuth.getInstance();
        if (firebaseAuth.getCurrentUser() != null) {
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
            finish();
        }
        email=findViewById(R.id.email);
        password=findViewById(R.id.password);
        loginbutton=findViewById(R.id.login);
        loginbutton.setOnClickListener(this);
        signup=findViewById(R.id.createtext);
        signup.setOnClickListener(this);


    }

    public void userlogin(){
        String email1=email.getText().toString().trim();
        String password1=password.getText().toString().trim();
        if(TextUtils.isEmpty(email1)){
            Toast.makeText(login.this,"please entgier email",Toast.LENGTH_LONG).show();

            return;
        }
        if(TextUtils.isEmpty(password1))
        {
            Toast.makeText(login.this,"please enter password",Toast.LENGTH_LONG);
            return;
        }
        progressDialog.show();
        firebaseAuth.signInWithEmailAndPassword(email1,password1)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete( Task<AuthResult> task) {
                        if(task.isSuccessful()){

                            startActivity(new Intent(getApplicationContext(), MainActivity.class));
                            finish();
                            progressDialog.dismiss();

                        }
                        else{
                            progressDialog.dismiss();
                            Toast.makeText(login.this,"please enter valid username or password",Toast.LENGTH_LONG).show();
                        }
                    }
                });

    }
    @Override
    public void onClick(View v) {
        if(v==loginbutton)
        {
            userlogin();
        }
        if (v == signup) {
            finish();
            startActivity(new Intent(getApplicationContext(),register.class));
        }

    }
}

